#include "home.h"

Home::Home()
{
    this->allBathroom = 0;
    this->allKitchen = 0;
    this->allLivingRoom = 0;
}

int Home::isAllClicked(){
    if (this->allBathroom and this->allKitchen and this->allLivingRoom){    // si toutes les objets des trois pièces ont été cliqués
        return 1;
    }
    return 0;
}

void Home::setClickedObj(int value){    // change le nombre d'objet cliqués
    this->total_clicked = value;
}

