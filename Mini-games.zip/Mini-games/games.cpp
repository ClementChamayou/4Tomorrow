#include "games.h"
#include "ui_games.h"

Games::Games(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Games)
{
    ui->setupUi(this);

    // fenêtre principale
    QPixmap pixmap("Images/blue.jpg");
    QPalette palette;
    palette.setBrush(this->backgroundRole(), QBrush(pixmap));
    this->setPalette(palette);

    QPixmap pixmap1("Images/MJ1.png");
    ui->logoMJ1->setPixmap(pixmap1);
    QPixmap pixmap2("Images/trash.png");
    ui->logoMJ2->setScaledContents(true);
    ui->logoMJ2->setPixmap(pixmap2);
    QPixmap pixmap3("Images/slicedHouse.jpg");
    ui->logoMJ3->setScaledContents(true);
    ui->logoMJ3->setPixmap(pixmap3);
    ui->logoMJ1->hide();
    ui->logoMJ2->hide();
    ui->logoMJ3->hide();
    ui->Puzzle->hide();
    ui->TrashTime->hide();
    ui->HomeEvolve->hide();
    ui->Easy->hide();
    ui->Medium->hide();
    ui->Hard->hide();
    ui->Name_2->hide();
    this->flag = 0;

    player = new QMediaPlayer;
    audioOutput = new QAudioOutput;
    player->setAudioOutput(audioOutput);

    player->setSource(QUrl::fromLocalFile("Images/music_princ.mp3"));
    audioOutput->setVolume(50);
    player->play();

}

Games::~Games()
{
    delete ui;
}

void Games::on_Easy_clicked()
{
    std::string level = "Easy";
    Puzzle *puzzle = new Puzzle(level);
    puzzle->setFixedSize(1200,700);
    puzzle->show();
    player->stop();
}


void Games::on_Medium_clicked()
{
    std::string level = "Medium";
    Puzzle *puzzle = new Puzzle(level);
    puzzle->setFixedSize(1200,700);
    puzzle->show();
    player->stop();
}


void Games::on_Hard_clicked()
{
    std::string level = "Hard";
    Puzzle *puzzle = new Puzzle(level);
    puzzle->setFixedSize(1200,700);
    puzzle->show();
    player->stop();

}


void Games::on_Puzzle_clicked()
{
    this->ui->Easy->show();
    this->ui->Medium->show();
    this->ui->Hard->show();

}



void Games::on_TrashTime_clicked()
{

    TrashTime *trashtime = new TrashTime();
    trashtime->setFixedSize(1200, 700);
    trashtime->show();
    player->stop();
}


void Games::on_Enter_clicked()
{

    ui->alias->hide();
    QString content_label = this->ui->Name->toPlainText();  // on récupère le pseudo du joueur

    ui->Name_2->show();

    this->ui->Name->hide();
    this->ui->Name_2->setText(content_label);   // on l'affiche
    ui->Name_2->show();


    this->ui->logoMJ1->show();
    this->ui->logoMJ2->show();
    this->ui->logoMJ3->show();
    this->ui->Puzzle->show();
    this->ui->TrashTime->show();
    this->ui->HomeEvolve->show();
    this->ui->Enter->hide();


}

void Games::on_Sound_clicked()
{
    if (flag == 0){
       this->player->stop();
        flag = 1;
    }
    else{
        this->player->play();
        flag = 0;
    }
}


void Games::on_HomeEvolve_clicked()
{
    WinHome *winHome = new WinHome();
    winHome->show();
    player->stop();
}

