#ifndef MINIGAMES_H
#define MINIGAMES_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MiniGames; }
QT_END_NAMESPACE

class MiniGames : public QMainWindow
{
    Q_OBJECT

public:
    MiniGames(QWidget *parent = nullptr);
    ~MiniGames();

private:
    Ui::MiniGames *ui;
};
#endif // MINIGAMES_H
