#include "kitchen.h"
#include "ui_kitchen.h"



/* ce code n'est pas commenté car "bathroom.c" l'est (même classe) */

Kitchen::Kitchen(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Kitchen)
{
    ui->setupUi(this);

    QPixmap pixmap1("Images/kitchen.png");
    ui->im_kitchen->setPixmap(pixmap1);

    this->clicked1 = 0;
    this->clicked2 = 0;
    this->clicked3 = 0;
    this->clicked4 = 0;
    room_clickedObj = 0;
    this->ui->label->hide();

}

Kitchen::~Kitchen()
{
    delete ui;
}



int Kitchen::isAllClicked(){

    if (this->room_clickedObj == 4){
        this->allKitchen = 1;
        this->close();
        return 1;
    }
    return 0;
}


void Kitchen::on_Tap_clicked()
{
    if (!clicked1){
        this->ui->label->setText("Quand nous faisons fonctionner un robinet pendant une minute, c’est 10 à 12 litres d’eau qui s’ajoutent à notre consommation."
                                 "Pour faire baisser votre consommation en eau courante, la meilleure astuce est de poser des réducteurs de débits sur vos robinets."
                                 "Si vous avez un jardin, pensez à installer un récupérateur d’eau de pluie"
                                 "Si possible, installez une chasse d’eau à double débit.");
        this->ui->label->show();
        clicked1 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/4." );
        this->setClickedObj(this->room_clickedObj);

    }
}


void Kitchen::on_Microwave_clicked()
{
    if (!clicked2){
        this->ui->label->setText("Avec un micro-ondes, on utilise en moyenne moins d’énergie qu’avec un four. Pour optimiser l’utilisation de son micro-ondes et faire de économies d’électricité , il existe toutefois des truc et astuces  :"

                                 "En premier lieu, utiliser un micro-ondes plutôt qu’un four pour réchauffer les plats est bien plus économe."
                                 "Vous pouvez découper les grosses pièces en petits morceaux pour diminuer le temps de cuisson "
                                 "Nettoyer le micro-ondes une fois par semaine permet d’améliorer la performance du micro-ondes "
                                 "Débrancher la prise lorsque le micro-ondes n’est pas utilisé permet d’éviter une consommation passive, en particulier pendant les vacances ou congés prolongés. ");
        this->ui->label->show();
        clicked2 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/4." );
        this->setClickedObj(this->room_clickedObj);

    }
}


void Kitchen::on_Oven_clicked()
{
    if (!clicked3){
        this->ui->label->setText("La consommation d’un four électrique a peu d’impact si vous l’utilisez peu. En revanche, si vous l’utilisez 2 heures par jour, alors là oui, vous aurez une belle note d’électricité à la fin de l’année."
                                "Si vous souhaitez utiliser votre four de façon intense, tout en contrôlant votre consommation, il y a trois choses que vous pouvez faire :"
                                "Acheter un four électrique à basse consommation."
                                "Le second levier que vous avez, est de cuisiner vos plats pendant les heures creuses");

        this->ui->label->show();
        clicked3 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/4." );
        this->setClickedObj(this->room_clickedObj);

    }
}


void Kitchen::on_Fridge_clicked()
{
    if (!clicked4){

        this->ui->label->setText("Comment faire baisser la consommation électrique de votre frigo ?"
                                 "La première chose à faire est de prendre soin des joints d’étanchéité des portes, pour qu’ils durent le plus longtemps possible. Ensuite, on fera attention au réglage du thermostat, qui n’a pas besoin d’être bloqué sur le minimum. Plus la température demandée est basse, plus la consommation électrique du frigo est importante, et plus la facture est élevée."
                                 "Enfin des gestes simples comme refermer rapidement la porte lorsqu’on l’ouvre, ne pas surcharger le frigo, ne pas y ranger de produits chauds (les faire refroidir avant), ou encore décongeler ses aliments dans le frigo pour en baisser la température permettront de réaliser des économies substantielles.");

        this->ui->label->show();
        clicked4 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/4." );
        this->setClickedObj(this->room_clickedObj);

    }
}


void Kitchen::on_OK_clicked()
{
    if(isAllClicked()){
        QMessageBox::information(this, "Done", "You have found every discoverable objects in this room.");
    }
    this->ui->label->hide();
}

