#ifndef TRASHTIME_H
#define TRASHTIME_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QMessageBox>

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include "game.h"

class Games;
namespace Ui {
class TrashTime;
}

class TrashTime : public QWidget, public Game
{
    Q_OBJECT

public:
    explicit TrashTime(QWidget *parent = nullptr);
    ~TrashTime();
    void display_image(int i);  // affiche l'image (elles sont identifiées par un nombre)
    void confirm(std::string no);     // vérification de la réponse avec un fichier texte qui contient les réponses
    void setCombo(int value);   // change le combo
    void setScore(int value);   // change le score

private slots:
    void on_Play_clicked();

    void on_yellow_clicked();

    void on_brown_clicked();

    void on_blue_clicked();

    void on_green_clicked();

    void on_none_clicked();

    void on_Sound_clicked();

    void on_ChangeGame_clicked();

private:
    Ui::TrashTime *ui;
    QMediaPlayer *game;

    int noQuestion; // pour pouvoir parcourir le fichier texte des questions
    int noAnswer;   // pour pouvoir parcourir le fichier texte des réponses
    int answer;     // itérateur pour parcourir le fichier texte des réponses
    int combo;      // combo du jeu
    int score;      // score du jeu
    std::string noAnswer1;// pour pouvoir savoie quelle réponse le joueur a coché
    int flag;       // flag pour le son (on/off)
};

#endif // TRASHTIME_H
