#ifndef GAME_H
#define GAME_H

#include <string>
#include <stdlib.h>

class Puzzle;
class Game
{

public:
    Game();
    void set_combo(int value);  // change la valeur du combo
    void change_game();         // quand l'utilisateur change de mini-jeu


protected:

    int isLevel;    // s'il y a un level ou non
    int score;      // score du jeu
    int combo;      // combo du jeu

};

#endif // GAME_H
