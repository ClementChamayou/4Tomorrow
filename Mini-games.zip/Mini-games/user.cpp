#include "user.h"

User::User(char* name)
{

    this->_name = name;

    // initialement les paramètres sont à zéro
    this->_total_score = 0;
}

void User::set_score(int value){
    this->_total_score = value;
}



