#ifndef WINHOME_H
#define WINHOME_H

#include <QWidget>
#include <QMessageBox>

#include <kitchen.h>
#include <bathroom.h>
#include <livingroom.h>

namespace Ui {
class WinHome;
}

class WinHome : public QWidget
{
    Q_OBJECT

public:
    explicit WinHome(QWidget *parent = nullptr);
    ~WinHome();


private slots:
    void on_Rules_clicked();

    void on_Kitchen_clicked();

    void on_Bathroom_clicked();

    void on_Livingroom_clicked();

    void on_ChangeGame_clicked();

private:
    Ui::WinHome *ui;
    QMediaPlayer *game;

};

#endif // WINHOME_H
