#ifndef HOME_H
#define HOME_H

#include <QPushButton>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QMessageBox>

#include "game.h"

class Home : public Game
{
public:
    Home();

    void setClickedObj(int value);  // lorsque le joueur

    virtual int isAllClicked();     // renvoie 1 si le joueur a cliqué sur tous les boutons du jeu
    int room_clickedObj;



protected:

    int allKitchen;     // égal à 1 si tous les boutons de la cuisine ont été appuyés
    int allLivingRoom;  // égal à si tous les boutons du salon ont été appuyés
    int allBathroom;    // égal à si tous les boutons de la salle de bain ont été appuyés
    int total_clicked;  // égal au nombre d'objet cliqués
};



#endif // HOME_H
