#include "livingroom.h"
#include "ui_livingroom.h"



/* ce code n'est pas commenté car "bathroom.c" l'est (même classe) */


LivingRoom::LivingRoom(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LivingRoom)
{
    ui->setupUi(this);

    QPixmap pixmap1("Images/living_room.jpg");
    ui->im_livingroom->setPixmap(pixmap1);

    this->clicked1 = 0;
    this->clicked2 = 0;
    this->clicked3 = 0;
    room_clickedObj = 0;

    this->ui->label->hide();

}

LivingRoom::~LivingRoom()
{
    delete ui;
}

int LivingRoom::isAllClicked(){

    if (this->room_clickedObj == 3){
        this->allLivingRoom = 1;

        QPixmap pixmap("Images/youwinWBG.png");
        this->ui->im_livingroom->setScaledContents(true);
        this->ui->im_livingroom->setPixmap(pixmap);
        this->ui->label->hide();
        return 1;
    }
    return 0;
}




void LivingRoom::on_Light_clicked()
{
    if (!clicked1){

        this->ui->label->setText("Aujourd’hui, l’éclairage représente 15% de la facture d’électricité des ménages. Des gestes simples du quotidien peuvent permettre de diminuer ce poste de dépense de manière significative.\n "
                                "Eteignez la lumière lorsque vous sortez d’une pièce et apprenez à votre famille à en faire de même."
                                "Utilisez des ampoules basse consommation. Ces dernières ont une durée de vie trois fois plus longue et consomment jusqu’à dix fois moins. Ne manquez pas cette aubaine !"
                                "Dépoussiérez vos ampoules et vos abat-jours : la poussière diminue le rendement lumineux."
                                "Adaptez la puissance de vos ampoules selon vos besoins."
                                "Favorisez l’entrée de lumière naturelle, c’est gratuit !"
                                "Utilisez des tons clairs pour l’intérieur de votre habitat : l’utilisation de teintes foncées amène à doubler voire tripler l’intensité de l’éclairage."
                                "Evitez d’utiliser des lampes à ampoules halogènes  qui consomment dix fois plus que des ampoules classiques."
                                "Les lampes sont dotées d’étiquettes énergétiques . Ces dernières de A à G en fonction de leur capacité à être économiques. Privilégiez donc les lampes avec la mention « A » qui vous aideront à réduire votre budget éclairage."
                                "Installez des détecteurs de présence dans vos escaliers et vos couloirs."
                                "A l’extérieur de votre habitat, privilégiez les lampes photovoltaïques qui  fonctionnent gratuitement à l’énergie solaire.");

        this->ui->label->show();
        clicked1 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/3." );
        this->setClickedObj(this->room_clickedObj);

    }
}


void LivingRoom::on_radiator_clicked()
{
    if (!clicked2){

        this->ui->label->setText("Le chauffage est de loin le principal poste de dépenses énergétiques dans une maison. Plus la surface à chauffer est grande, plus la consommation d'électricité de la maison est forte et, par conséquent, plus la facture d'électricité est élevée.\n Quelques principes à respecter : Pensez à régler la température de confort de chacun de vos émetteurs. "
                                 "Une température idéale de 19°C   est recommandée dans les pièces à vivre et 17°C dans les chambres. Ne chauffez pas les pièces qui ne sont pas occupées à plein temps (chambre, bureau)."
                     "Baissez la consigne de votre thermostat avant de vous coucher."
                     "Pensez à programmer votre chauffage si vos équipements le permettent.");
        this->ui->label->show();

        clicked2 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/3." );
        this->setClickedObj(this->room_clickedObj);

    }
}


void LivingRoom::on_TV_clicked()
{
    if (!clicked3){

        this->ui->label->setText("La consommation moyenne d'un téléviseur varie en fonction de plusieurs critères :"
                                 "la taille de l'écran, la technologie, la résolution, la fréquence et la connectivité."
                                 "Il est possible de baisser sa consommation d'électricité liée à la télévision par deux façons \n :"
                                 "diminuer le nombre de kWh consommé :"
                                 "choisir un téléviseur dernier cri : les nouvelles technologiques sont moins consommatrices d'énergie que les anciens. Par conséquent, lors de l'achat d'une nouvelle TV, il est préférables d'opter pour Ultra HD, LED ou OLED, plutôt qu'une TV LCD, Plasma ou cathodiques ;"
                                 "ne pas laisser la télévision en veille : le téléviseur consomme un peu lorsqu'il est en mode veille ;"
                                 "débrancher tous les appareils annexes : lorsque le home cinéma, la console de jeux, le décodeur ou encore la lecteur DVD ou Blu-Ray ne sont pas en cours d'utilisation, il est conseillé de les mettre hors tension. Un appareil en veille consomme encore de l'électricité. ");
        this->ui->label->show();

        clicked3 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/3." );
        this->setClickedObj(this->room_clickedObj);

    }
}


void LivingRoom::on_OK_clicked()
{
    if(isAllClicked()){
        QMessageBox::information(this, "Done", "You have found every discoverable objects in this room.");
        this->ui->OK->hide();
    }
    this->ui->label->hide();

}

