#include "minigames.h"
#include "ui_minigames.h"

MiniGames::MiniGames(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MiniGames)
{
    ui->setupUi(this);
}

MiniGames::~MiniGames()
{
    delete ui;
}

