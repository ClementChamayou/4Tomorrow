#include "minigames.h"

#include <QApplication>
#include "games.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Games w;
    w.setFixedSize(900, 444);   // on fixe une taille de fenêtre
    w.show();                   // on affiche la fenêtre
    return a.exec();
}
