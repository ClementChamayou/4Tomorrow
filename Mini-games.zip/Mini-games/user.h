#ifndef USER_H
#define USER_H


#include <stdio.h>
#include <stdlib.h>

class User
{
public:
    User(char* name);

    //getter
    float get_total_score(){ return _total_score; };    // retourne le score du joueur
    char* get_name(){ return _name; };                  // retourne le pseudo du joueur

    //setter
    void set_score(int value);

private:
    char* _name;
    int _total_score;
};

#endif // USER_H
