#ifndef GAMES_H
#define GAMES_H

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QMessageBox>
#include "user.h"
#include "puzzle.h"
#include "trashtime.h"
#include "winhome.h"
#include "home.h"

namespace Ui {
class Games;
}

class Games : public QWidget
{
    Q_OBJECT

public:
    explicit Games(QWidget *parent = nullptr);
    ~Games();

/* l'utilisateur clique sur des boutons */
private slots:
    void on_Enter_clicked();

    void on_Easy_clicked();

    void on_Medium_clicked();

    void on_Hard_clicked();

    void on_Puzzle_clicked();

    void on_TrashTime_clicked();

    void on_Sound_clicked();

    void on_HomeEvolve_clicked();

private:
    Ui::Games *ui;

protected:
    QMediaPlayer *player;       // musique du jeu
    QAudioOutput *audioOutput;
    int flag;                   // flag pour le son (on/off)
};

#endif // GAMES_H
