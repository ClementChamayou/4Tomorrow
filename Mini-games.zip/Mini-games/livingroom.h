#ifndef LIVINGROOM_H
#define LIVINGROOM_H

#include <QWidget>

#include "home.h"

namespace Ui {
class LivingRoom;
}

class LivingRoom : public QWidget, public Home
{
    Q_OBJECT

public:
    explicit LivingRoom(QWidget *parent = nullptr);
    ~LivingRoom();
    int isAllClicked(); // 0 par défaut, 1 si tous les objets sont cliqués

private slots:


    void on_Light_clicked();

    void on_radiator_clicked();

    void on_TV_clicked();

    void on_OK_clicked();

private:
    Ui::LivingRoom *ui;
    int clicked1, clicked2, clicked3;   // flag pour les boutons des objets (ils ne sont comptés qu'une seule fois)
};

#endif // LIVINGROOM_H
