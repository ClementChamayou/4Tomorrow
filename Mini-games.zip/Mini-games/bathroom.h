#ifndef BATHROOM_H
#define BATHROOM_H

#include <QWidget>

#include "home.h"

namespace Ui {
class Bathroom;
}

class Bathroom : public QWidget, public Home
{
    Q_OBJECT

public:
    explicit Bathroom(QWidget *parent = nullptr);
    ~Bathroom();
    int isAllClicked(); // 0 par défaut, 1 si tous les objets sont cliqués

private slots:


    void on_WashinhMachine_clicked();   // objet machine

    void on_Shower_clicked();           // objet douche

    void on_Bath_clicked();             // objet baignoire

    void on_OK_clicked();

private:
    Ui::Bathroom *ui;
    int clicked1, clicked2, clicked3;   // flag pour les boutons des objets (ils ne sont comptés qu'une seule fois)
};

#endif // BATHROOM_H
