#include "bathroom.h"
#include "ui_bathroom.h"

Bathroom::Bathroom(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Bathroom)
{
    ui->setupUi(this);

    QPixmap pixmap1("Images/bathroom.jpg"); // image de fond
    ui->im_bathroom->setPixmap(pixmap1);


    /* par défaut ces attributs sont à zéro */
    this->clicked1 = 0;
    this->clicked2 = 0;
    this->clicked3 = 0;
    room_clickedObj = 0;

    this->ui->label->hide();

}

Bathroom::~Bathroom()
{
    delete ui;
}


int Bathroom::isAllClicked(){

    if (this->room_clickedObj == 3){    // le nombre d'objet dans la pièce est de trois
        this->allBathroom = 1;
        this->close();                  // quand tous les objets ont été trouvés, la page se ferme
        return 1;
    }
    return 0;
}


void Bathroom::on_WashinhMachine_clicked()
{
    if (!clicked1){
        this->ui->label->setText("Outre la classe énergétique, d’autres facteurs ont un impact sur la consommation d’une machine à laver : "
                                 "la température de l'eau, la vitesse du cycle de lavage, laver son linge à 30, oublier le prélavage. ");
        this->ui->label->show();

        clicked1 = 1;   // le bouton ne sera cliqué qu'une fois
        this->room_clickedObj++;    // le nombre d'objet cliqués dans la chambre augmente
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/3." );
        this->setClickedObj(this->room_clickedObj);

    }

}


void Bathroom::on_Shower_clicked()
{
    if (!clicked2){
        this->ui->label->setText("La douche est idéale pour les personnes seules ou les couples et séduit pour son côté dynamisant et revivifiant."
                                 "Sachez qu’en moyenne, une douche consomme de 40 à 60 litres"
                                 "Même si la douche consomme beaucoup moins qu’une baignoire, il est toujours intéressant de réduire sa consommation d'eau et il existe différents moyens d’y parvenir sans rien changer à votre confort. "
                                 "Le simple fait de couper l’eau au moment de vous savonner vous permettra d’économiser 20 litres d’eau. Equiper les robinets d’aérateurs (ou de mousseurs)"
                                 "est un autre procédé intéressant car tout en injectant de l’air, ils permettent de garder la même pression. ");
        this->ui->label->show();
        clicked2 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/3." );
        this->setClickedObj(this->room_clickedObj);

    }
}


void Bathroom::on_Bath_clicked()
{
    if (!clicked3){
        this->ui->label->setText("Un bain consomme 120 à 200 litres."
                                 "Sachez que, même si le bain a tendance à consommer plus d’eau qu’une douche, il est toujours possible de trouver des alternatives pour économiser l’eau voire même la réutiliser."
                                 "Tout d’abord, pensez à ne pas remplir votre baignoire jusqu’en haut. Vous passerez un moment tout aussi agréable mais en économisant 50% sur votre consommation d’eau."
                                 "Pensez aussi à recycler l’eau de votre bain et de l’utiliser pour remplir le réservoir de vos toilettes.");
        this->ui->label->show();
        clicked3 = 1;
        this->room_clickedObj++;
        this->ui->clicked->setText("Number of clicked object : " + QString::number(this->room_clickedObj) + "/3." );
        this->setClickedObj(this->room_clickedObj);

    }

}


void Bathroom::on_OK_clicked()
{
    if(isAllClicked()){
        QMessageBox::information(this, "Done", "You have found every discoverable objects in this room.");
    }
    this->ui->label->hide();
}

