#ifndef PUZZLE_H
#define PUZZLE_H

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QMessageBox>
#include <QRadioButton>

#include "game.h"

namespace Ui {
class Puzzle;
}

class Puzzle : public QWidget,  public Game
{
    Q_OBJECT



public:
    explicit Puzzle(std::string level, QWidget *parent = nullptr);

    void display_puzzle(std::string user_level);    // affiche le puzzle avec le level choisi
    void set_nbPieces(int value);                   // change le nombre de pièces
    void question_puzzle();                         // fonction pour afficher les questions du jeu
    void answer_puzzle();                           // fonction pour afficher les réponses du jeu
    void set_Combo(int value);                      // changer le combo
    void set_score(int value);                      // changer le score du jeu
    char* get_level(){return level.data();}         // avoir accès au level du jeu

    friend bool operator&&(QRadioButton but1, QRadioButton but2);   // surcharge d'opérateur pour vérifier si deux boutons sont cliqués
    friend bool operator&&(QRadioButton but1, bool a);              // utile si on veut comparer plus de deux boutons
    friend bool operator&&(bool a, QRadioButton but2);              // idem

    friend bool operator||(QRadioButton but1, QRadioButton but2);   // surcharge d'opérateur pour vérifier au moins un des deux boutons a été cliqué
    friend bool operator||(QRadioButton but1, bool a);              // utile si on veut comparer trois boutons minimum
    friend bool operator||(bool a, QRadioButton but2);              // idem



    ~Puzzle();

private slots:
    void on_Rules_clicked();

    void on_Play_clicked();

    void on_Confirm_clicked();

    void on_ChangeGame_clicked();

    void on_Sound_clicked();

private:
    Ui::Puzzle *ui;
    QMediaPlayer *player;   // audio du jeu


    int noQuestion; // pour pouvoir parcourir le fichier texte des questions
    int noAnswer;   // pour pouvoir parcourir le fichier texte des réponses
    int answer;     // itérateur pour parcourir le fichier texte des réponses
    int nb_pieces;  // nombre de pièces du puzzle selon le niveau
    std::string level;  // level du puzzle
    int combo;          // combo courant
    int flag;           // flag pour l'audio (on/off)
};



#endif // PUZZLE_H
