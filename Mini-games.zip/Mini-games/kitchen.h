#ifndef KITCHEN_H
#define KITCHEN_H

#include <QWidget>

#include "home.h"

namespace Ui {
class Kitchen;
}

class Kitchen : public QWidget, public Home
{
    Q_OBJECT

public:
    explicit Kitchen(QWidget *parent = nullptr);
    ~Kitchen();
    int isAllClicked(); // 0 par défaut, 1 si tous les objets sont cliqués


private slots:


    void on_Tap_clicked();

    void on_Microwave_clicked();

    void on_Oven_clicked();

    void on_Fridge_clicked();

    void on_OK_clicked();

private:
    Ui::Kitchen *ui;
    int clicked1, clicked2, clicked3, clicked4; // flag pour les boutons des objets (ils ne sont comptés qu'une seule fois)
};

#endif // KITCHEN_H
