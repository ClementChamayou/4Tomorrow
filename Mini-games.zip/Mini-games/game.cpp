#include "game.h"

Game::Game()
{
    this->combo = 0;
    this->score = 0;
}


void Game::set_combo(int value){
    this->combo = value;
}
