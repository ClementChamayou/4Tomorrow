#include "winhome.h"
#include "ui_winhome.h"

WinHome::WinHome(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WinHome)
{
    ui->setupUi(this);

    QPixmap pixmap("Images/slicedHouse.jpg");
    ui->Home->setScaledContents(true);
    ui->Home->setPixmap(pixmap);

    // le joueur peut seulement aller dans une pièce après l'autre définie par ce code. Quand une pièce est finie, une autre se débloque
    ui->Livingroom->setEnabled(false);
    ui->Bathroom->setEnabled(false);

    game = new QMediaPlayer;
    QAudioOutput *audioOutput = new QAudioOutput;
    game->setAudioOutput(audioOutput);

    game->setSource(QUrl::fromLocalFile("Images/home.mp3"));
    game->play();


}

WinHome::~WinHome()
{
    delete ui;
}

void WinHome::on_Rules_clicked()
{
    QMessageBox::information(this, "Game rules", "GAME RULES \nThe aim of the game is to discover the little tricks of everyday life that can reduce the ecological impact of a house or apartment.\n The player selects a first room. Then he will have to find the clickable objects of the room.\nThe player wins and finishes the game when he finds all the discoverable objects of the house.");
}


void WinHome::on_Kitchen_clicked()
{
    Kitchen *kitchen = new Kitchen;

    kitchen->show();
    this->ui->Kitchen->setEnabled(false);
    this->ui->Bathroom->setEnabled(true);
}


void WinHome::on_Bathroom_clicked()
{
    Bathroom *bathroom = new Bathroom;

    bathroom->show();
    this->ui->Bathroom->setEnabled(false);
    this->ui->Livingroom->setEnabled(true);
}


void WinHome::on_Livingroom_clicked()
{
    LivingRoom *livingroom = new LivingRoom;

    livingroom->show();
    this->ui->Livingroom->setEnabled(false);

}

void WinHome::on_ChangeGame_clicked()
{
    this->hide();
    this->game->stop();
}

