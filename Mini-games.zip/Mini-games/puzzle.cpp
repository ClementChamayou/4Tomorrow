#include "puzzle.h"
#include "ui_puzzle.h"

Puzzle::Puzzle(std::string level, QWidget *parent) :

    QWidget(parent),
    ui(new Ui::Puzzle)
{
    ui->setupUi(this);

    QPixmap pixmap("Images/space.png");
    QPalette palette;
    palette.setBrush(this->backgroundRole(), QBrush(pixmap));
    this->setPalette(palette);

    this->noQuestion = 0;
    this->noAnswer = 0;
    this->answer = 0;
    this->nb_pieces = 0;
    this->combo = 0;
    this->isLevel = 1;

    this->level = level;

    ui->level->setText("LEVEL : " +  QString::fromStdString(this->get_level()));    // on affiche le level du puzzle

    /* son du jeu */
    player = new QMediaPlayer;
    QAudioOutput *audioOutput = new QAudioOutput;
    player->setAudioOutput(audioOutput);
    player->setSource(QUrl::fromLocalFile("Images/music_puzzle.mp3"));
    audioOutput->setVolume(70);
    player->play();


    ui->Rep1->hide();
    ui->Rep2->hide();
    ui->Rep3->hide();
    ui->Confirm->hide();
    ui->Answer->hide();
    ui->Image_finale->hide();


    display_puzzle(this->get_level());  // on affiche initialiement le puzzle vide

}

Puzzle::~Puzzle()
{
    delete ui;
}



/* surchage d'opérateur */
bool operator&&(QRadioButton but1, QRadioButton but2){
    return but1.isChecked() && but2.isChecked();
}

bool operator&&(QRadioButton but1, bool a){
    return but1.isChecked() && a;
}

bool operator&&(bool a, QRadioButton but2){
    return a && but2.isChecked();
}

bool operator||(QRadioButton but1, QRadioButton but2){
    return but1.isChecked()||but2.isCheckable();
}
bool operator||(QRadioButton but1, bool a){
    return but1.isChecked()||a;
}

bool operator||(bool a, QRadioButton but2){
    return a||but2.isChecked();
}


void Puzzle::set_nbPieces(int value){
    this->nb_pieces = value;
}

void Puzzle::set_Combo(int value){
    this->combo = value;
}

void Puzzle::set_score(int value){
    this->score = value;
}

void Puzzle::on_Rules_clicked() // affiche les règles si le joueur clique sur ce bouton
{
    // on affiche les règles dans unx box information
    QMessageBox::information(this, "Game rules", "GAME RULES \nThe aim of the game is to recreate the puzzle as quickly as possible \n"
                                                 "by answering questions about the environment."
                                                 " When your answer is good, your combo will increment by 1 : it helps you to win more "
                                                 "pieces at one time so the better you answer the questions, the faster you win ! ");
}

void Puzzle::display_puzzle(std::string level){

    QMediaPlayer *finish = new QMediaPlayer;
    QAudioOutput *audioOutput = new QAudioOutput;
    finish->setAudioOutput(audioOutput);

    finish->setSource(QUrl::fromLocalFile("Images/applause.mp3"));
    audioOutput->setVolume(30);

    if (strcmp(level.data(), "Easy") == 0){ // selon le niveau

        // on affiche les images que le joueur possède

        int compteur = 1;

        for (int i = 0; i <= 4; i++){   // 25 pièces
            for (int j = 0; j <= 4; j++){

                if (compteur <= this->nb_pieces){
                    QLabel *label = new QLabel(" ");
                    QPixmap pixmap("Images/PineTools.com_files/row-"+QString::number(i+1)+"-column-"+QString::number(j+1)+".png");
                    label->setPixmap(pixmap);

                    ((QGridLayout*)this->ui->Puzzle_2->layout())->addWidget(label, i, j);   // on place à des coordonnées précises les images
                    compteur++;
                }
                else
                    break;

            }
        }
        if (this->nb_pieces >= 25){ // si on dépass le nombre de pièces, on considère le puzzle terminé
            this->set_nbPieces(25);
            ui->Puzzle_2->hide();
            QPixmap pixmapfinal("image_complete.png");  // on affiche l'image originale
            ui->Image_finale->setPixmap(pixmapfinal);
            ui->Image_finale->show();
            finish->play();
            this->ui->Answer->hide();

        }
        ui->progressBar->setValue(nb_pieces*100/25);    // la progress bar est à 100%

     }

    else if (strcmp(level.data(), "Medium") == 0){

        // on affiche les images que le joueur possède

        int compteur = 1;

        for (int i = 0; i <= 7; i++){
            for (int j = 0; j <= 7; j++){

                if (compteur <= nb_pieces){

                    QLabel *label = new QLabel(" ");
                    QPixmap pixmap("Images/PineTools.com_files1/row-"+QString::number(i+1)+"-column-"+QString::number(j+1)+".png");
                    label->setPixmap(pixmap);

                    ((QGridLayout*)this->ui->Puzzle_2->layout())->addWidget(label, i, j);
                    compteur++;
                }
                else
                    break;

            }
        }
        if (nb_pieces >= 64){
            this->set_nbPieces(64);
            ui->Puzzle_2->hide();
            QPixmap pixmapfinal("image_complete1.png");
            ui->Image_finale->setPixmap(pixmapfinal);
            ui->Image_finale->show();
            finish->play();
            this->ui->Answer->hide();

        }
        ui->progressBar->setValue(nb_pieces*100/64);

     }

    else {

        // on affiche les images que le joueur possède

        int compteur = 1;

        for (int i = 0; i <= 10; i++){
            for (int j = 0; j <= 10; j++){

                if (compteur <= nb_pieces){
                    QLabel *label = new QLabel(" ");
                    QPixmap pixmap("Images/PineTools.com_files2/row-"+QString::number(i+1)+"-column-"+QString::number(j+1)+".png");
                    label->setPixmap(pixmap);

                    ((QGridLayout*)this->ui->Puzzle_2->layout())->addWidget(label, i, j);
                    compteur++;
                }
                else
                    break;

            }
        }
        if (nb_pieces >= 121){
            this->set_nbPieces(121);
            ui->Puzzle_2->hide();
            QPixmap pixmapfinal("image_complete2.png");
            ui->Image_finale->setPixmap(pixmapfinal);
            ui->Image_finale->show();
            finish->play();
            this->ui->Answer->hide();

        }

        ui->progressBar->setValue(nb_pieces*100/121);
     }

    ui->nb_pieces->setText("Pieces : " + QString::number(nb_pieces));
    ui->combo->setText("Combo : " + QString::number(this->combo));

}

void Puzzle::question_puzzle(){

   std::ifstream fichier_q("Images/questions.txt");
   if (fichier_q){
       std::string quest;
       for (int i = 0; i <= this->noQuestion; i++){ // on parcourt le fichier texte des questions et on affiche la nouvelle ligne
           getline(fichier_q, quest);
           this->ui->Question->setText(QString::fromStdString(quest));
       }
       this->noQuestion++;
   }


}

void Puzzle::answer_puzzle(){

    ui->Answer->show();
    std::ifstream fichier_a("Images/answers.txt");
    if (fichier_a){
        std::string rep;
        for (int j = 0; j <= this->noAnswer; j++){  // on affiche les trois réponses suivantes
            getline(fichier_a, rep);
            this->ui->Rep1->setText(QString::fromStdString(rep));
            getline(fichier_a, rep);
            this->ui->Rep2->setText(QString::fromStdString(rep));
            getline(fichier_a, rep);
            this->ui->Rep3->setText(QString::fromStdString(rep));


        }
        this->noAnswer++;
    }

}

void Puzzle::on_Confirm_clicked()
{
    std::ifstream fichier_nr("Images/noAnswerPuzzle.txt");

    std::string player_answer;
    if (fichier_nr){

        // si au moins un des trois boutons a été appuyé
        if (this->ui->Rep1 || this->ui->Rep2 || this->ui->Rep3){

            // on regarde quelle case a été cochée
            if (this->ui->Rep1->isChecked()){
                player_answer = "1";
            }
            else if (this->ui->Rep2->isChecked()){
                player_answer = "2";
            }
            else{
                player_answer = "3";
            }

            // il faut regarder si c'est la bonne réponse
            std::string noRep;
            for (int j = 0; j <= this->answer; j++){
                getline(fichier_nr, noRep);

            }
            this->answer++;
            int nv_piece = this->nb_pieces;
            int nv_combo = this->combo;

            char arr[noRep.length() + 1];
            strcpy(arr, noRep.c_str());

            // si le joueur répond juste
            if (strcmp(arr, player_answer.data())==0){

                QMediaPlayer *right = new QMediaPlayer;
                QAudioOutput *audioOutput = new QAudioOutput;
                right->setAudioOutput(audioOutput);

                right->setSource(QUrl::fromLocalFile("Images/good.mp3"));
                audioOutput->setVolume(30);
                right->play();

                nv_combo++; // le combo augmente
                nv_piece++;
                this->set_score(1+nv_combo);

            }
            // si le joueur répond faux
            else{
                QMediaPlayer *wrong = new QMediaPlayer;
                QAudioOutput *audioOutput = new QAudioOutput;
                wrong->setAudioOutput(audioOutput);

                wrong->setSource(QUrl::fromLocalFile("Images/wrong.mp3"));
                audioOutput->setVolume(10);
                wrong->play();

                nv_combo = 0;
            }


            this->set_Combo(nv_combo);  // on màj les nouvelles données
            nv_piece += nv_combo;
            this->set_nbPieces(nv_piece);

            on_Play_clicked();
        }

        else
            QMessageBox::information(this, "No answer", "You didn't choose an answer.");

    }


}

void Puzzle::on_Play_clicked()
{


    ui->Rep1->show();
    ui->Rep2->show();
    ui->Rep3->show();
    ui->Confirm->show();
    ui->Play->hide();


    display_puzzle(this->level);
    // on appelle une fonction pour afficher une question
    question_puzzle();
    // on appelle une fonction pour afficher les réponses disponibles
    answer_puzzle();
}

void Puzzle::on_Sound_clicked()
{
    if (flag==0){
        this->player->stop();
        flag = 1;
    }
    else{
        this->player->play();
        flag = 0;
    }
}


void Puzzle::on_ChangeGame_clicked()
{
    this->hide();
    this->player->stop();
}


