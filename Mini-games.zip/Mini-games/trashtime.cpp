#include "trashtime.h"
#include "ui_trashtime.h"

TrashTime::TrashTime(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TrashTime)
{
    ui->setupUi(this);

    QPixmap pixmap("Images/trashh.jpg");
    QPalette palette;
    palette.setBrush(this->backgroundRole(), QBrush(pixmap));
    this->setPalette(palette);

    this->isLevel = 0;


    QPixmap pixmap0("Images/yellow_bin.png");
    ui->im_yellow->setPixmap(pixmap0);
    QPixmap pixmap1("Images/blue_bin.png");
    ui->im_blue->setPixmap(pixmap1);
    QPixmap pixmap2("Images/brown_bin.png");
    ui->im_brown->setPixmap(pixmap2);
    QPixmap pixmap3("Images/green_bin.png");
    ui->im_green->setPixmap(pixmap3);
    QPixmap pixmap4("Images/none.png");
    ui->im_none->setPixmap(pixmap4);
    ui->Image->setText("GAME RULES \nThe aim of the game is to make the best score !\n Forty images of waste will appear on the screen one after the other and the player must press the color of the trash that corresponds");

    ui->im_none->hide();
    ui->im_blue->hide();
    ui->im_brown->hide();
    ui->im_green->hide();
    ui->im_yellow->hide();
    ui->blue->hide();
    ui->brown->hide();
    ui->yellow->hide();
    ui->green->hide();
    ui->none->hide();
    ui->Objet->hide();

    game = new QMediaPlayer;
    QAudioOutput *audioOutput = new QAudioOutput;
    game->setAudioOutput(audioOutput);

    game->setSource(QUrl::fromLocalFile("Images/TrashTime.mp3"));
    game->play();


    /* par défaut c'est à 0 */
    this->noQuestion = 0;
    this->noAnswer = 0;
    this->answer = 0;
    this->combo = 0;
    this->flag = 0;
    this->ui->Combo->setText("Combo : 0");
    this->ui->Score->setText("Score : 0");

}

void TrashTime::setCombo(int value){
    this->combo = value;
}

void TrashTime::setScore(int value){
    this->score = value;
}

TrashTime::~TrashTime()
{
    delete ui;
}

void TrashTime::display_image(int i){
    QPixmap pixmap("Images/TrashTime/" + QString::number(i) +".png");   // on affiche l'imahe du déchet
    ui->Image->setPixmap(pixmap);
    std::ifstream fichier_nr("Images/answerTrashTime.txt");
    std::string rep;
    for (int j = 0; j <= this->answer; j++){    // on parcourt le fichier texte pour afficher ce à quoi correspond
        getline(fichier_nr, rep);
        this->ui->Objet->setText(QString::fromStdString(rep));

    }
    this->answer++;

}

void TrashTime::on_Play_clicked()
{

    this->ui->im_none->show();
    this->ui->im_blue->show();
    this->ui->im_brown->show();
    this->ui->im_green->show();
    this->ui->im_yellow->show();
    this->ui->blue->show();
    this->ui->brown->show();
    this->ui->green->show();
    this->ui->yellow->show();
    this->ui->none->show();
    this->ui->Play->hide();
    this->ui->Objet->show();

    display_image(1); // on affiche la premiere image
    this->noAnswer++;

}

void TrashTime::confirm(std::string no)
{
    std::ifstream fichier_nr("Images/noAnswerTrashTime.txt");
    if (fichier_nr){


        // il faut regarder si c'est la bonne réponse
        std::string noRep;
        for (int j = 0; j <= this->noAnswer-1; j++){
            getline(fichier_nr, noRep);

        }
        this->noAnswer++;
        int nv_combo = this->combo;
        int nv_score = this->score;

        char arr[noRep.length() + 1];
        strcpy(arr, noRep.c_str());

        // si le joueur répond juste
        if (no == noRep){

            QMediaPlayer *right = new QMediaPlayer;
            QAudioOutput *audioOutput = new QAudioOutput;
            right->setAudioOutput(audioOutput);

            right->setSource(QUrl::fromLocalFile("Images/good.mp3"));
            audioOutput->setVolume(30);
            right->play();

            nv_combo++; // le combo augmente
            this->ui->Combo->setText(QString::number(nv_combo));


        }
        // si le joueur répond faux
        else{
            QMediaPlayer *wrong = new QMediaPlayer;
            QAudioOutput *audioOutput = new QAudioOutput;
            wrong->setAudioOutput(audioOutput);

            wrong->setSource(QUrl::fromLocalFile("Images/wrong.mp3"));
            audioOutput->setVolume(10);
            wrong->play();

            nv_combo = 0;   // le combo passe à zéro
        }
        this->setCombo(nv_combo);
        nv_score += nv_combo;
        this->setScore(nv_score);


       ui->progressBar->setValue((this->noAnswer-1)*100/40);
       ui->Combo->setText("Combo : " + QString::number(this->combo));
       ui->Score->setText("Score : " + QString::number(this->score));

       if ((this->noAnswer-1)*100/40 == 100){

            this->ui->im_none->hide();
            this->ui->im_blue->hide();
            this->ui->im_brown->hide();
            this->ui->im_green->hide();
            this->ui->im_yellow->hide();
            this->ui->blue->hide();
            this->ui->brown->hide();
            this->ui->yellow->hide();
            this->ui->green->hide();
            this-> ui->none->hide();
            this-> ui->Objet->hide();



       }
       display_image(this->noAnswer);


    }
}

// selon la poubelle affichée, on met une valeur dans noAnswer et on regarde si c'est la bonne réponse
void TrashTime::on_yellow_clicked()
{
    noAnswer1 = "1";
    confirm(noAnswer1);

}

void TrashTime::on_brown_clicked()
{
    noAnswer1 = "2";
    confirm(noAnswer1);
}


void TrashTime::on_blue_clicked()
{
    noAnswer1 = "3";
    confirm(noAnswer1);

}

void TrashTime::on_green_clicked()
{
    noAnswer1 = "4";
    confirm(noAnswer1);
}

void TrashTime::on_none_clicked()
{
    noAnswer1 = "5";
    confirm(noAnswer1);
}


void TrashTime::on_Sound_clicked()
{
    if (flag==0){
        this->game->stop();
        flag = 1;
    }
    else{
        this->game->play();
        flag = 0;
    }
}


void TrashTime::on_ChangeGame_clicked()
{
    this->hide();
    this->game->stop();
}

